g++ testing\ code.cpp -o testing.out
